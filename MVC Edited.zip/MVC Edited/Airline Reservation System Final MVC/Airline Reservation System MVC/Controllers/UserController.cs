﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.Web.Mvc.Html;
using System.Web.Security;
using Airline_Reservation_System_MVC.Models;

namespace Airline_Reservation_System_MVC.Controllers
{
    public class UserController : Controller
    {
        TrainingEntities db = new TrainingEntities();

        // GET: User
        public ActionResult Index()
        {
            return View();
        }

        //Function  to search a flight
        public ActionResult ViewFlight(string Origin, string Destination, string txtTravelDate)
        {
            List<Flight> FlightList = db.Flights.ToList();

            ViewBag.Origin = new SelectList(db.Flights, "Origin", "Origin");
            ViewBag.Destination = new SelectList(db.Flights, "Destination", "Destination");

            var query = db.Flights.Where(s => s.Origin == Origin && s.Destination == Destination);

            ViewBag.FlightList = query.ToList();
            ViewBag.TravelDate = txtTravelDate;


            return View();
        }

        public ActionResult BookTicket(string flId)
        {
            ViewBag.FlightID = flId;
            //ViewBag.FlightID = new SelectList(db.Flights, "FlightID", "FlightID");
            //IEnumerable<string> classes = new List<string>() { "First Class", "Economy Class", "Business Class" };
            //ViewBag.FlightClass = classes;

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookTicket([Bind(Include = "TicketNumber,TicketNo,FlightID,DateofBooking,JourneyDate,PassengerName,Age,Gender,ContacNo,Email,Class,NoofTickets,TotalFare,ReservationStatus")] Reservation reservation)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    reservation.DateofBooking = DateTime.Today.Date;
                    reservation.ReservationStatus = "Booked";
                    decimal Fare = db.FlightClasses.First(t => t.Class == reservation.Class && t.FlightID == reservation.FlightID).Fare;
                    reservation.TotalFare = reservation.NoofTickets * Fare;
                    db.Reservations.Add(reservation);
                    db.SaveChanges();
                    ViewBag.Status = true;

                    ViewBag.Tickets = reservation.NoofTickets;
                    ViewBag.TicketFare = reservation.TotalFare;
                    ViewBag.TicketNo = db.Reservations.Select(t => t.TicketNo).Max();
                    ViewBag.FlightID = new SelectList(db.Flights, "FlightID", "FlightID");
                    return View();
                }
            }
            catch (Exception ex)
            {

            }
            ViewBag.FlightID = new SelectList(db.Flights, "FlightID", "FlightID");

            return View(reservation);
        }

        // Function to View a ticket
        public ActionResult ViewTicket(string TicketNo)
        {
            List<Reservation> ReservationList = db.Reservations.ToList();

            ViewBag.TicketNo = new SelectList(db.Reservations, "TicketNo", "TicketNo");
            var query = db.Reservations.Where(s => s.TicketNo == TicketNo);

            ViewBag.ReservationList = query.ToList();
            return View();
        }

        // Function to cancel ticket
        public ActionResult CancelTicket(string TicketNo)
        {
            //List<Reservation> TicketList = db.Reservations.ToList();
            ViewBag.TicketNo = TicketNo;
            //ViewBag.TicketNo = new SelectList(db.Reservations, "TicketNo", "TicketNo");

            db.USP_CancelTicket1(TicketNo);
            //ViewBag.TicketList = query.ToString();

            var query = from res in db.Reservations
                        where (res.TicketNo == TicketNo)
                        select res.TotalFare;

            ViewBag.TotalFare = query.SingleOrDefault();

            return View();
        }

        public ActionResult AboutUs()
        {
            return View();
        }

        public ActionResult ContactUs()
        {
            return View();
        }
        public ActionResult AdminLogin()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AdminLogin(User objUser)
        {
            if (ModelState.IsValid)
            {

                var obj = db.Users.Where(a => a.Username.Equals(objUser.Username)
                                           && a.UserPassword.Equals(objUser.UserPassword)).FirstOrDefault();
                if (obj != null)
                {
                    Session["Username"] = obj.Username.ToString();
                    return RedirectToAction("../Admin/AdminHome");
                }
                else
                {
                    ModelState.AddModelError("", "Login data is incorrect!");
                }

            }
            return View(objUser);
        }



    }
}