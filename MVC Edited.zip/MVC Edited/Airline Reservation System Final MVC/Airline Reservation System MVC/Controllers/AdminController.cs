﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.Web.Mvc.Html;
using System.Web.Security;
using Airline_Reservation_System_MVC.Models;

namespace Airline_Reservation_System_MVC.Controllers
{
    public class AdminController : Controller
    {
        TrainingEntities db = new TrainingEntities();
        
        public ActionResult AdminHome()
        {
            if (Session["Username"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("AdminLogin");
            }
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("../User/AdminLogin");
        }

        public ActionResult AddFlight()
        {

            ViewBag.Hide = true;

            return View();
        }

        // POST: Flights/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public ActionResult AddFlight([Bind(Include = "FlightID,LaunchDate,Origin,Destination,DeptTime,ArrivalTime,NoOfSeats,Class,Fare,TotalSeats")] ModelView modelView)
        {
            if (ModelState.IsValid)
            {
                Flight flight = new Flight();
                FlightClass flightClass = new FlightClass();
                db.Flights.Add(flight);
                db.FlightClasses.Add(flightClass);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(modelView);
        }

        // Function to remove a fligth
        public ActionResult RemoveFlight(string FlightID)
        {
            //List<Flight> FlightList = db.Flights.ToList();

            ViewBag.FlightID = new SelectList(db.Flights, "FlightID", "FlightID");
            db.USP_FLIGHTDELETE(FlightID);

            return View();

        }


        public ActionResult OverallRevenue()
        {
            ViewBag.TotalFare = new SelectList(db.Reservations, "TotalFare", "TotalFare");
            var query = db.Reservations.Sum(s => s.TotalFare);
            ViewBag.OverallRev = query.ToString();
            return View();
        }

        public ActionResult FlightRevenue(string FlightID)
        {
            List<Flight> FlightList = db.Flights.ToList();
            ViewBag.Flights = new SelectList(db.Flights, "FlightID", "FlightID");
            var query = db.Reservations.Sum(s => s.TotalFare);
            ViewBag.FlightRev = query.ToString();
            return View();
        }



    }
}