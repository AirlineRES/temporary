﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Airline_Reservation_System_MVC.Models
{
    public class ModelView
    {

        public Flight flight { get; set; }
        public FlightClass flightClass { get; set; }
        public Reservation reservation { get; set; }
        public User user { get; set; }
    }
}